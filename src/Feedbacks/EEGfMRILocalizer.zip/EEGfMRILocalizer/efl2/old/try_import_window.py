#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sat Sep  1 12:46:22 2018

@author: johan
"""

from psychopy import visual

win3=visual.Window(fullscr=False,allowGUI=True,size=(800, 600))


