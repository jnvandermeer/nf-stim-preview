# so we have several tasks

'''
# first task = for loop

1) Loopup table for vis stimulus + draw em + send over event(if any) to evhandler

2) lookup which stop things to draw + draw them

3) send over which frame we're currently in for audio to separate audioprocess

4) AWAIT the win.flip (16 msec break)



# second task = the stop inhibit

1) figure out what needs to be on the screen depending on timing (in seconds or in frames?)

2) check out the keyboard (did they press?) periodically + upkeep of responses

3) send trigger codes (i.e. when did they press + when does something change)

4) maintenance on the staircases

'''

