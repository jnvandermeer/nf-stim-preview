# -*- coding: utf-8 -*-
"""
Created on Wed Sep  5 12:12:28 2018

@author: User
"""

print __name__